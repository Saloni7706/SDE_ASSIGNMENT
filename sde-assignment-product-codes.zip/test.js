import { processData } from './productCodeProcessor.js'; 

const sampleInput = ["abc1234", "XYZ0001", "123ABCD", "A1B2C3D", "lmn9876", "DEF5678"];

console.log(processData(sampleInput));
